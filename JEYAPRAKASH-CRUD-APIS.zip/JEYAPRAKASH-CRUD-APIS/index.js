// index.js
const express = require('express');
const connectDB = require('./db');
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;


const app = express();
const PORT = process.env.PORT || 3000;

const { createOrganization, getOrganizations, createUser, getUser, updateUser, deleteUser } = require('./Crud');
const { Organization, User } = require('./model');

// Passport configuration
passport.use(
    new LocalStrategy((username, password, done) => {
        User.findOne({ username: username, password: password }, async (err, user) => {
            if (err) return done(err);
            if (!user) return done(null, false, { message: 'Incorrect username.' });
            return done(null, user);
            // if (user.role == "admin") {
            //     const organizations = await Organization.findOne({ _id: user.organization });
            //     user.organization = await organizations.name
            //     return done(null, user);

            // } else {
            //     return done(null, user.name);
            // }



        });
    })
);

passport.serializeUser((user, done) => {
    done(null, user.id);
});

passport.deserializeUser((id, done) => {
    User.findById(id, (err, user) => {
        done(err, user);
    });
});

// Express middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(
    require('express-session')({
        secret: 'your-secret-key',
        resave: true,
        saveUninitialized: true,
    })
);
app.use(passport.initialize());
app.use(passport.session());

// Connect to MongoDB
connectDB();

// API endpoints
app.post('/login', passport.authenticate('local'), async (req, res) => {
    console.log("ressssssssssssss", res)
    res.json({ message: 'Login successful' });
});

app.get('/logout', (req, res) => {
    req.logout();
    res.json({ message: 'Logout successful' });
});

app.post('/organizations', async (req, res) => {
    try {
        const organization = await createOrganization(req.body);
        res.json(organization);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get('/organizations', async (req, res) => {
    try {
        const organizations = await getOrganizations();
        res.json(organizations);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/users', async (req, res) => {
    try {
        const user = await createUser(req.body);
        res.json(user);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get('/admindataonly', async (req, res) => {
    try {
        const user = await getUser(req.body.id);
        if (user) {
            res.json(user);
        } else {
            res.json({ "massese": "it's not a admin" })
        }

    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.put('/usersUpdate', async (req, res) => {
    try {
        const user = await updateUser(req.body.id, req.body);
        res.json(user);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.delete('/deleteuser', async (req, res) => {
    try {
        await deleteUser(req.body.id);
        res.json({ message: 'User deleted successfully' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Server start
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
